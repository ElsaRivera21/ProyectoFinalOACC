<?php
require 'funciones.php';

$dbms = 'mysql';
$host = '172.20.0.4';
$user = 'root';
$pass = 'r00t_p4ssw0rd';
$db   = 'db';

$arr_campos_usuarios = array('username','nombre', 'ap_paterno', 'ap_materno');

$arr_campos_usuarios_nn = array('username','nombre', 'ap_paterno', 'ap_materno');

?>
